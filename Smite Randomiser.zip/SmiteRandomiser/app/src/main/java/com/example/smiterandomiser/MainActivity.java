package com.example.smiterandomiser;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button bt;
        TextView texto;
        TextView consejos;

        bt = findViewById(R.id.bt);
        texto = findViewById(R.id.texto);
        consejos= findViewById(R.id.consejos);

        final String[] a = {"Achilles", "Amc", "Agni", "Ah puch", "Amaterasu", "Anhur", "Anubis", "Ao kuang", "Aphrodite", "Apollo", "Arachne", "Ares", "Artemis", "Artio", "Athena", "Atlas", "Awilix",
                "Baba Yaga", "Bacchus", "Bakasura", "Baron Samedi", "Bastet", "Bellona", "Cabrakan", "Camazotz", "Cerberus", "Cernunnos", "Chaac", "Change", "Charybdis", "Chernobog", "Chiron",
                "Chronos", "Cliodhna", "Cthulhu", "CuChulainn", "Cupid", "Da Ji", "Danzaburou", "Discordia", "Erlang Shen", "Eset", "Fafnir", "Fenrir", "Freya", "Ganesha", "Geb", "Gilgamesh", "Guan Yu",
                "Hachiman", "Hades", "He Bo", "Heimdallr", "Hel", "Hera", "Hercules", "Horus", "Hou Yi", "Hun Batz", "Isthar", "Izanami", "Janus", "Jing Wei", "Jormungandr", "Kali", "Khepri", "King Arthur",
                "Kukulkan", "Kumbhakarna", "Kuzenbo", "Loki", "Lancelot", "Maui", "Medusa", "Mercury", "Merlin", "Morgana", "Mulan", "Ne Zha", "Neith", "Nemesis", "Nike", "Nox", "Nu Wa", "Odin", "Olorun", "Osiris",
                "Pele", "Persephone", "Poseidon", "Ra", "Raijin", "Rama", "Ratatoskr", "Ravana", "Scylla", "Serqet", "Set", "Shiva", "Skadi", "Sobek", "Sol", "Sun Wukong", "Susano", "Sylvanus", "Terra",
                "Thanatos", "The Morrigan", "Thor", "Thoth", "Tiamat", "Tsukuyomi", "Tyr", "Ullr", "Vamana", "Vulcan", "Xbalanque", "Xing Tian", "Yemoja", "Ymir", "Yu Huang", "Zeus", "Zhong Kui"};

        final String[] b = {"La bandera es una mierda",
                            "Los junglas deben ir a hacerle el puto blue al solo",
                            "No dejarle la solo a juanmiguel",
                            "Smite tiene 123 dioses, pues 60 son la copia del anterior dijo testicles",
                            "Yemoja no usa mana, asi que jose no compres el caliz de mana",
                            "Comprar antihealing para los hades, el truco que nadie sabe en elo patata",
                            "El panteon polinesio lo diseño el becario"};

        Random c = new Random();
        int h = c.nextInt(7);
        consejos.setText(b[h]);

        bt.setOnClickListener(view -> {
            Random r = new Random();
            int g = r.nextInt(123);
            texto.setText(a[g]);
        });
    }
}